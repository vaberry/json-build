# json-build

## Installation

```python
pip install json-build
```